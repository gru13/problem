#include <stdio.h>
#include <string.h>

#include "usefulTools.h"


int main(int argc, char *argv[]) {
  unsigned char stringIn[MAX_STRING_SIZE];
  unsigned char stringOut[MAX_STRING_SIZE];

  // Determine if debugging should be on or not
  unsigned char debug = isDebugMode(argc, argv);

  // Get the sentence from the user
  unsigned char numBytesIn = getInputString(stringIn);

  unsigned char numBytesOut;





  // INSERT YOUR CODE HERE
  // Make sure that you: 
  //    1. Store the result string into stringOut
  //    2. Set the numBytesOut value to the length of stringOut




	
  // If debugging is on, display the expanded string as sequences of 8-bit binary values
  if (debug) {
    printf("Input bytes = %d\n\n", numBytesIn);
    printf("Output bytes = %d\n\n", numBytesOut);
    printf("Expansion ratio = %1.1f%%\n\n", 100*(float)(numBytesOut/(float)numBytesIn));
    printf("Before expansion:\n");
    for (int i=0; i<numBytesIn; i++)
      printAs8BitBinary(stringIn[i]);
    printf("\n");
	
    printf("After expansion:\n");
    for (int i=0; i<numBytesOut; i++)
      printAs6BitBinary(stringOut[i]);
    printf("\n");
		
    printf("Here is the resulting string:\n");
  }

  // Output to the next program
  sendOutputString(numBytesOut, stringOut);
}


