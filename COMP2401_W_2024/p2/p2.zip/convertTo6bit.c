#include <stdio.h>
#include <string.h>

#include "usefulTools.h"


int main(int argc, char *argv[]) {
  unsigned char stringIn[MAX_STRING_SIZE+1];
  unsigned char stringOut[MAX_STRING_SIZE+1];

  // Determine if debugging should be on or not
  unsigned char debug = isDebugMode(argc, argv);
	
  // Get the sentence from the user
  scanf("%[^\n]s", stringIn);
  unsigned char numBytesIn = strlen(stringIn);





  // INSERT YOUR CODE HERE
  // Make sure that you store the resulting string into stringOut






  // If debugging is on, display the converted string as 2 digit codes
  if (debug) {
    printf("%d bytes entered\n", numBytesIn);
    for (int i=0; i<=numBytesIn; i++)
      printf("%02d ", stringOut[i]);
    printf("\n");
  }
  
  // Output to the next program
  sendOutputString(numBytesIn, stringOut);
}


