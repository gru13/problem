#include <stdio.h>
#include <stdlib.h>

#include "obstacles.h"

int randint(int a);

// Return 1 if line segment (v1---v2) intersects line segment (v3---v4), otherwise return 0
unsigned char linesIntersect(short v1x, short v1y, short v2x, short v2y, short v3x, short v3y, short v4x, short v4y) {
	float uA = ((v4x-v3x)*(v1y-v3y) - (v4y-v3y)*(v1x-v3x)) / (float)(((v4y-v3y)*(v2x-v1x) - (v4x-v3x)*(v2y-v1y)));
	float uB = ((v2x-v1x)*(v1y-v3y) - (v2y-v1y)*(v1x-v3x)) / (float)(((v4y-v3y)*(v2x-v1x) - (v4x-v3x)*(v2y-v1y)));

	// If uA and uB are between 0-1, there is an intersection
	if (uA > 0 && uA < 1 && uB > 0 && uB < 1) 
		return 1;

	return 0;
}



// Create a graph using the numVertices and k parameters of the given environment.
void createGraph(Environment *env) {
	int xTemp, yTemp, inObs;
	env->vertices = (Vertex**)malloc(env->numVertices*sizeof(Vertex*));
	// Creating the vertex
	for(int v = 0;v<env->numVertices;v++){
		xTemp = randint(env->maximumX);
		yTemp = randint(env->maximumY);
		inObs = 1;
		for(int i = 0;i < env->numObstacles;i++){
			Obstacle* o = &env->obstacles[i];
			if((xTemp <= o->x + o->w) && ( xTemp >= o->x) && (yTemp <= o->y) && (yTemp >= o->y - o->h)){
				inObs = 0;
			}
		}
		if(inObs == 0){
			v--;
			continue;
		}
		env->vertices[v] = (Vertex*)malloc(sizeof(Vertex));
		env->vertices[v]->x = xTemp;
		env->vertices[v]->y = yTemp;
	}
	// Connecting the vertices
	for(int i = 0;i<env->numVertices;i++){
		int dist[env->numVertices];
		int sel[env->k];  
		short x1 = env->vertices[i]->x;
		short y1 = env->vertices[i]->y;
		int min_dist = __INT_MAX__;
		int min_index = -1;
		// finding the dist from that vertice to other
		for (int j = 0; j < env->numVertices; j++){
			short x2 = env->vertices[j]->x;
			short y2 = env->vertices[j]->y;
			dist[j] = (x2-x1)*(x2-x1) + (y2-y1)*(y2-y1);
			if(dist[j] < min_dist){
				min_dist = dist[j];
				min_index = j;
			}
		}
		// selecting the first k element with smallest distance
		sel[0] = min_index;
		min_index = -1;
		for(int a = 1;a<env->k;a++){
			min_dist = __INT_MAX__;
			min_index = -1;
			for(int b = 0;b<env->numVertices;b++){
				if(dist[b] < min_dist && dist[b] > dist[sel[a-1]]){
					min_dist = dist[b];
					min_index = b;
				} 
			}
			sel[a] = min_index;			
		}
		// checking the if they are intersecting
		for(int a = 0 ; a < env->k ;a++){
			short x2 = env->vertices[sel[a]]->x;
			short y2 = env->vertices[sel[a]]->y;
			int flag = 0;
			for(int b = 0; b < env->numObstacles; b++){
				short xr = env->obstacles[b].x;
				short yr = env->obstacles[b].y;
				short w = env->obstacles[b].w;
				short h = env->obstacles[b].h;
				if((int)linesIntersect(x1,y2,x2,y2,xr,yr,xr+w,yr) == 1){
					flag  = 1;
				}
				if((int)linesIntersect(x1,y2,x2,y2,xr,yr,xr,yr+h) == 1){
					flag  = 1;

				}
				if((int)linesIntersect(x1,y2,x2,y2,xr,yr+h,xr+w,yr+h) == 1){
					flag  = 1;

				}
				if((int)linesIntersect(x1,y2,x2,y2,xr+w,yr,xr+w,yr+h) == 1){
					flag  = 1;
				}
			}
			if(flag == 1){
				// printf("gurg");
				sel[a] *= -1;

			}
		}
		// joining the un intersected edges
		env->vertices[i]->neighbours = (Neighbour*)malloc(sizeof(Neighbour));
		Neighbour* head = env->vertices[i]->neighbours;
		for(int a = 0 ;a<env->k;a++){
			
			printf("%d ",sel[a]);
			if(sel[a] > 0){
				head->vertex = env->vertices[sel[a]];
				if(a == env->k-1){
					head->next = NULL;
				}else{
					head->next = (Neighbour*)malloc(sizeof(Neighbour));
					head = head->next;
				}
			}
		}
		printf("%d\n",i);
	}
}


// This procedure cleans up everything by freeing all allocated memory
void cleanupEverything(Environment *env) {
    for (int i = 0; i < env->numVertices; i++) {
        free(env->vertices[i]->neighbours);
        free(env->vertices[i]); 
    }
    free(env->vertices);
    free(env->obstacles);
}


int randint(int a){ 
	return rand()%a;
}