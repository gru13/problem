#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include "restaurant.h"


void main() {
	int                 clientSocket;  // client socket id
	struct sockaddr_in  clientAddress; // client address
	int                 status;
	
}


