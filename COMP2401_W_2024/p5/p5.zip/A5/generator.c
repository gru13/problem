#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>

#include "restaurant.h"

void main() {
  // Set up the random seed
  srand(time(NULL));

}

