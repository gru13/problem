#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define C_OK            0
#define C_NOK          -1
#define C_TRUE          1
#define C_FALSE         0

#define MAX_STR        64
#define MAX_CAP       128

#define PATRON_IDS   1001
#define RES_IDS      4001

typedef struct {
  int   id;
  char  name[MAX_STR];
} PatronType;

typedef struct {
  int day;
  int month;
  int year;
  int hours;
  int minutes;
} ResvTimeType;

typedef struct {
  int           id;
  PatronType   *patron;
  ResvTimeType *resvTime;
} ResvType;

/*** Define the PatronArrayType here ***/

/*** Define the NodeType here ***/

/*** Define the ResvListType here ***/

/*** Define the RestaurantType here ***/


void printMenu(int*);
void loadPatronData(RestaurantType*);
void loadResData(RestaurantType*);

