#include "defs.h"

int main(int argc, char *argv[])
{

  return(0);
}

int randomInt(int max)
{
  return(rand() % max);
}

